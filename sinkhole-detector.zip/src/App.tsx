import React, { useState, useEffect, useRef } from 'react';
import { 
  Shield, 
  Upload, 
  MapPin, 
  AlertTriangle, 
  Activity, 
  History, 
  Layers, 
  Database, 
  Info, 
  Trash2, 
  RotateCcw, 
  Map as MapIcon, 
  TrendingUp, 
  FileText,
  Clock,
  Compass,
  Cpu,
  CheckCircle,
  Eye
} from 'lucide-react';

interface SinkholeDetection {
  box: number[]; // [ymin, xmin, ymax, xmax] as percentages 0-100
  confidence: number;
  estimatedDiameterMeters: number;
  riskLevel: 'low' | 'medium' | 'high';
  riskScore: number;
  description: string;
  locationName?: string;
  latitude?: number;
  longitude?: number;
}

interface ScanRecord {
  id: string;
  timestamp: string;
  fileName: string;
  fileType: 'satellite' | 'drone' | 'ground';
  imageUrl: string;
  location: {
    lat: number;
    lng: number;
    locationName: string;
  };
  soilType: string;
  geologicalRiskAssessment: string;
  isHighRiskAlert: boolean;
  detections: SinkholeDetection[];
}

// Generate high-quality SVG Demo Images as Data URIs so they run immediately
const getFloridaDemoImage = () => {
  const svg = `
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 800 600" width="800" height="600">
      <rect width="800" height="600" fill="#1b241b"/>
      <!-- Grid lines -->
      <path d="M 0,100 L 800,100 M 0,200 L 800,200 M 0,300 L 800,300 M 0,400 L 800,400 M 0,500 L 800,500 M 100,0 L 100,600 M 200,0 L 200,600 M 300,0 L 300,600 M 400,0 L 400,600 M 500,0 L 500,600 M 600,0 L 600,600 M 700,0 L 700,600" stroke="#2a382a" stroke-width="1"/>
      <!-- Residential roads -->
      <path d="M 50,250 L 750,250 M 50,450 L 750,450 M 250,50 L 250,550" stroke="#4a5568" stroke-width="30" stroke-linecap="round"/>
      <path d="M 50,250 L 750,250 M 50,450 L 750,450 M 250,50 L 250,550" stroke="#cbd5e0" stroke-width="2" stroke-dasharray="10,10" stroke-linecap="round"/>
      <!-- Houses layout -->
      <rect x="80" y="120" width="50" height="50" fill="#2d3748" rx="5"/>
      <rect x="150" y="120" width="50" height="50" fill="#2d3748" rx="5"/>
      <rect x="350" y="120" width="50" height="50" fill="#2d3748" rx="5"/>
      <rect x="420" y="120" width="50" height="50" fill="#2d3748" rx="5"/>
      <rect x="80" y="320" width="50" height="50" fill="#2d3748" rx="5"/>
      <rect x="150" y="320" width="50" height="50" fill="#2d3748" rx="5"/>
      <rect x="350" y="320" width="50" height="50" fill="#2d3748" rx="5"/>
      <rect x="420" y="320" width="50" height="50" fill="#2d3748" rx="5"/>
      <!-- Big active sinkhole in the middle -->
      <ellipse cx="400" cy="250" rx="140" ry="110" fill="#0d110d"/>
      <!-- Soil erosion contour rings -->
      <ellipse cx="400" cy="250" rx="120" ry="92" fill="none" stroke="#e53e3e" stroke-width="4" stroke-opacity="0.8"/>
      <ellipse cx="400" cy="250" rx="100" ry="76" fill="none" stroke="#dd6b20" stroke-width="3" stroke-dasharray="15,10" stroke-opacity="0.6"/>
      <ellipse cx="400" cy="250" rx="75" ry="57" fill="none" stroke="#d69e2e" stroke-width="2" stroke-opacity="0.5"/>
      <ellipse cx="400" cy="250" rx="45" ry="34" fill="#050705"/>
      <!-- Water body at bottom of sinkhole -->
      <ellipse cx="390" cy="255" rx="30" ry="20" fill="#1d3557" fill-opacity="0.7"/>
      <!-- Tension fractures on roads -->
      <path d="M 230,220 Q 235,235 242,240 Q 248,245 252,260" stroke="#f56565" stroke-width="3" fill="none"/>
      <path d="M 530,265 Q 525,275 515,278 Q 500,282 490,290" stroke="#f56565" stroke-width="3" fill="none"/>
      <!-- Text label -->
      <text x="30" y="50" fill="#48bb78" font-family="monospace" font-size="20" font-weight="bold">SPECTRAL BAND: INTRUSION RADAR</text>
      <text x="30" y="80" fill="#e53e3e" font-family="monospace" font-size="16" font-weight="bold">WARNING: HIGH CARRIER DISPLACEMENT DETECTED</text>
    </svg>
  `;
  return `data:image/svg+xml;utf8,${encodeURIComponent(svg)}`;
};

const getDeadSeaDemoImage = () => {
  const svg = `
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 800 600" width="800" height="600">
      <rect width="800" height="600" fill="#dfd3be"/>
      <!-- Turquoise Coastline of Dead Sea -->
      <path d="M 0,350 Q 200,320 400,380 Q 600,440 800,360 L 800,600 L 0,600 Z" fill="#0077b6"/>
      <path d="M 0,350 Q 200,320 400,380 Q 600,440 800,360" stroke="#90e0ef" stroke-width="12" fill="none" stroke-opacity="0.7"/>
      <!-- Multiple coastal dissolution sinkholes -->
      <!-- Doline 1 -->
      <ellipse cx="300" cy="200" rx="80" ry="60" fill="#2d2214"/>
      <ellipse cx="300" cy="200" rx="72" ry="54" fill="none" stroke="#e53e3e" stroke-width="3"/>
      <ellipse cx="300" cy="200" rx="60" ry="45" fill="#1c140c"/>
      <ellipse cx="295" cy="202" rx="40" ry="30" fill="#03045e" fill-opacity="0.8"/>
      <!-- Doline 2 (Adjacent active) -->
      <ellipse cx="550" cy="280" rx="100" ry="75" fill="#2d2214"/>
      <ellipse cx="550" cy="280" rx="90" ry="67" fill="none" stroke="#e53e3e" stroke-width="4"/>
      <ellipse cx="550" cy="280" rx="70" ry="52" fill="none" stroke="#dd6b20" stroke-dasharray="10,5" stroke-width="2"/>
      <ellipse cx="550" cy="280" rx="50" ry="37" fill="#1c140c"/>
      <ellipse cx="545" cy="282" rx="35" ry="26" fill="#023e8a" fill-opacity="0.9"/>
      <!-- Fissure cracks in desert soil -->
      <path d="M 220,180 Q 150,160 100,170" stroke="#744d2e" stroke-width="4" fill="none"/>
      <path d="M 380,210 Q 450,220 480,240" stroke="#744d2e" stroke-width="4" fill="none"/>
      <path d="M 470,300 Q 420,330 380,310" stroke="#744d2e" stroke-width="3" fill="none"/>
      <!-- Salt crust polygons -->
      <polygon points="120,80 150,70 170,90 140,110" fill="none" stroke="#f4efe6" stroke-width="2"/>
      <polygon points="170,90 210,80 220,110 180,120" fill="none" stroke="#f4efe6" stroke-width="2"/>
      <polygon points="90,120 130,115 140,150 100,160" fill="none" stroke="#f4efe6" stroke-width="2"/>
      <!-- Labels -->
      <text x="30" y="50" fill="#a0522d" font-family="monospace" font-size="20" font-weight="bold">SPECTRAL BAND: SWIR (SHORT-WAVE IR)</text>
      <text x="30" y="80" fill="#d00000" font-family="monospace" font-size="16" font-weight="bold">SUBSURFACE SALT DISSOLUTION ZONE DETECTED</text>
    </svg>
  `;
  return `data:image/svg+xml;utf8,${encodeURIComponent(svg)}`;
};

const getTennesseeDemoImage = () => {
  const svg = `
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 800 600" width="800" height="600">
      <defs>
        <linearGradient id="grass" x1="0%" y1="0%" x2="0%" y2="100%">
          <stop offset="0%" stop-color="#38a169"/>
          <stop offset="100%" stop-color="#22543d"/>
        </linearGradient>
        <linearGradient id="sky" x1="0%" y1="0%" x2="0%" y2="100%">
          <stop offset="0%" stop-color="#4299e1"/>
          <stop offset="100%" stop-color="#ebf8ff"/>
        </linearGradient>
      </defs>
      <!-- Sky -->
      <rect width="800" height="250" fill="url(#sky)"/>
      <!-- Grass Slope -->
      <polygon points="0,200 800,250 800,600 0,600" fill="url(#grass)"/>
      <!-- Barbwire Fence -->
      <line x1="0" y1="230" x2="800" y2="280" stroke="#718096" stroke-width="3"/>
      <line x1="0" y1="260" x2="800" y2="310" stroke="#718096" stroke-width="2"/>
      <line x1="200" y1="200" x2="200" y2="400" stroke="#5c4033" stroke-width="12"/>
      <line x1="600" y1="210" x2="600" y2="410" stroke="#5c4033" stroke-width="12"/>
      <!-- Fence wood grains -->
      <line x1="197" y1="220" x2="197" y2="380" stroke="#4a2e1b" stroke-width="2"/>
      <line x1="597" y1="230" x2="597" y2="390" stroke="#4a2e1b" stroke-width="2"/>
      <!-- Deep sudden sinkhole void in the middle -->
      <path d="M 300,350 Q 400,320 500,360 Q 550,420 520,480 Q 400,520 280,470 Q 250,400 300,350 Z" fill="#1a120b"/>
      <!-- Inner collapse void -->
      <path d="M 320,370 Q 400,350 480,380 Q 510,430 490,460 Q 400,490 310,450 Q 290,400 320,370 Z" fill="#000000"/>
      <!-- Cracking around the throat -->
      <path d="M 300,350 L 250,330 M 500,360 L 560,350 M 520,480 L 560,510 M 280,470 L 220,500" stroke="#dd6b20" stroke-width="3"/>
      <path d="M 250,330 L 210,335 M 560,350 L 610,345" stroke="#dd6b20" stroke-width="1.5"/>
      <!-- Exposing soil strata inside hole -->
      <path d="M 280,420 Q 300,440 310,450" stroke="#a0aec0" stroke-width="4" fill="none"/>
      <!-- Labels -->
      <text x="30" y="50" fill="#2b6cb0" font-family="monospace" font-size="20" font-weight="bold">SPECTRAL BAND: VISIBLE HIGH-RES PHOTOGRAPHY</text>
      <text x="30" y="80" fill="#dd6b20" font-family="monospace" font-size="16" font-weight="bold">ALERT: IMMEDIATE VOID THROAT COLLAPSE DETECTED</text>
    </svg>
  `;
  return `data:image/svg+xml;utf8,${encodeURIComponent(svg)}`;
};

export default function App() {
  const [history, setHistory] = useState<ScanRecord[]>([]);
  const [activeScan, setActiveScan] = useState<ScanRecord | null>(null);
  const [selectedFileType, setSelectedFileType] = useState<'satellite' | 'drone' | 'ground'>('satellite');
  
  // Custom manual coordinate injection
  const [useManualCoordinates, setUseManualCoordinates] = useState<boolean>(false);
  const [manualLat, setManualLat] = useState<string>('28.538336');
  const [manualLng, setManualLng] = useState<string>('-81.379234');
  const [manualRegionName, setManualRegionName] = useState<string>('Florida Karst Belt');

  // Interactive States
  const [uploadedImage, setUploadedImage] = useState<string>('');
  const [uploadedFileName, setUploadedFileName] = useState<string>('');
  const [isAnalyzing, setIsAnalyzing] = useState<boolean>(false);
  const [analysisProgress, setAnalysisProgress] = useState<number>(0);
  const [progressText, setProgressText] = useState<string>('');
  const [hoveredBoxIdx, setHoveredBoxIdx] = useState<number | null>(null);
  const [errorMessage, setErrorMessage] = useState<string>('');

  // Search and filter history
  const [searchTerm, setSearchTerm] = useState<string>('');
  const [filterType, setFilterType] = useState<string>('all');
  const [filterRisk, setFilterRisk] = useState<string>('all');

  // Leaflet map reference
  const mapRef = useRef<any>(null);
  const mapContainerId = "leaflet-dashboard-map";
  const [mapMarkers, setMapMarkers] = useState<any[]>([]);

  // Fetch scan history on startup
  useEffect(() => {
    fetchHistory();
  }, []);

  const fetchHistory = async () => {
    try {
      const res = await fetch('/api/history');
      if (res.ok) {
        const data = await res.json();
        setHistory(data);
        if (data.length > 0 && !activeScan) {
          setActiveScan(data[0]);
        }
      }
    } catch (err) {
      console.error("Failed to load historical scans:", err);
    }
  };

  // Re-render map pins when activeScan or history changes
  useEffect(() => {
    if (!window.L || !activeScan) return;

    // Initialize map if it doesn't exist
    if (!mapRef.current) {
      const container = document.getElementById(mapContainerId);
      if (container) {
        mapRef.current = window.L.map(mapContainerId, {
          center: [activeScan.location.lat, activeScan.location.lng],
          zoom: 11,
          scrollWheelZoom: true,
          fadeAnimation: true
        });

        // Add Leaflet tile layers
        window.L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
          maxZoom: 19,
          attribution: '© OpenStreetMap contributors'
        }).addTo(mapRef.current);

        // Apply dark overlay filter to map container
        container.classList.add('dark-map');
      }
    }

    // Set map center to current activeScan coordinate
    if (mapRef.current) {
      mapRef.current.setView([activeScan.location.lat, activeScan.location.lng], 12);
    }

    // Clear existing markers
    mapMarkers.forEach(m => m.remove());
    const newMarkers: any[] = [];

    // Pin active scan in red/cyan, other historical scans in slate
    history.forEach((record) => {
      const isActive = record.id === activeScan.id;
      const lat = record.location.lat;
      const lng = record.location.lng;

      if (window.L) {
        // Create custom SVG colored dot icons for beautiful look
        const iconHtml = `
          <div class="relative flex items-center justify-center">
            <span class="animate-ping absolute inline-flex h-6 w-6 rounded-full ${isActive ? (record.isHighRiskAlert ? 'bg-red-500' : 'bg-emerald-400') : 'bg-slate-500'} opacity-60"></span>
            <span class="relative inline-flex rounded-full h-4 w-4 ${isActive ? (record.isHighRiskAlert ? 'bg-red-600' : 'bg-emerald-500') : 'bg-slate-600'} border-2 border-slate-900 shadow-lg"></span>
          </div>
        `;

        const customIcon = window.L.divIcon({
          html: iconHtml,
          className: 'custom-leaflet-icon',
          iconSize: [24, 24],
          iconAnchor: [12, 12]
        });

        const marker = window.L.marker([lat, lng], { icon: customIcon })
          .addTo(mapRef.current)
          .bindPopup(`
            <div style="font-family: sans-serif; font-size: 13px; line-height: 1.4;">
              <strong style="color: #10b981;">Scan ID: ${record.id}</strong><br/>
              <strong>Location:</strong> ${record.location.locationName}<br/>
              <strong>Soil Profile:</strong> ${record.soilType}<br/>
              <strong>Detections:</strong> ${record.detections.length} collapse voids<br/>
              <strong>Risk Level:</strong> <span style="font-weight: bold; color: ${record.isHighRiskAlert ? '#ef4444' : '#10b981'}">${record.isHighRiskAlert ? 'HIGH RISK' : 'STABLE / LOW'}</span><br/>
              <button onclick="window.dispatchLoadScan('${record.id}')" style="margin-top: 8px; width: 100%; border: none; padding: 4px 8px; background: #10b981; color: white; border-radius: 4px; cursor: pointer; font-size: 11px; font-weight: bold;">Focus Scan</button>
            </div>
          `);

        newMarkers.push(marker);
      }
    });

    setMapMarkers(newMarkers);

    // Bind global dispatcher for marker popups
    (window as any).dispatchLoadScan = (id: string) => {
      const matched = history.find(item => item.id === id);
      if (matched) {
        setActiveScan(matched);
      }
    };

  }, [activeScan, history]);

  // Handle file select/drag-drop
  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    processImageFile(file);
  };

  const processImageFile = (file: File) => {
    const reader = new FileReader();
    reader.onload = (event) => {
      if (event.target?.result) {
        setUploadedImage(event.target.result as string);
        setUploadedFileName(file.name);
        setErrorMessage('');
      }
    };
    reader.readAsDataURL(file);
  };

  // Drag over drop handler
  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    const file = e.dataTransfer.files?.[0];
    if (file) {
      processImageFile(file);
    }
  };

  // Load a demo image
  const loadDemo = (type: 'florida' | 'dead_sea' | 'tennessee') => {
    let imgUri = '';
    let fName = '';
    let fType: 'satellite' | 'drone' | 'ground' = 'satellite';

    if (type === 'florida') {
      imgUri = getFloridaDemoImage();
      fName = "florida_winter_park_scan.svg";
      fType = "satellite";
      setUseManualCoordinates(true);
      setManualLat('28.538336');
      setManualLng('-81.379234');
      setManualRegionName('Orange County, Florida, USA');
    } else if (type === 'dead_sea') {
      imgUri = getDeadSeaDemoImage();
      fName = "dead_sea_coastline_scan.svg";
      fType = "drone";
      setUseManualCoordinates(true);
      setManualLat('31.458623');
      setManualLng('35.395217');
      setManualRegionName('Ein Gedi Dissolution Coast, Dead Sea');
    } else {
      imgUri = getTennesseeDemoImage();
      fName = "tennessee_collapsed_doline.svg";
      fType = "ground";
      setUseManualCoordinates(true);
      setManualLat('36.162663');
      setManualLng('-86.781601');
      setManualRegionName('Tennessee Karst Valley, USA');
    }

    setUploadedImage(imgUri);
    setUploadedFileName(fName);
    setSelectedFileType(fType);
    setErrorMessage('');
  };

  // Run the multi-spectral scan
  const executeScan = async () => {
    if (!uploadedImage) {
      setErrorMessage("Please select or drop an image first, or load a preset demo scenario.");
      return;
    }

    setIsAnalyzing(true);
    setAnalysisProgress(5);
    setProgressText("Calibrating multi-spectral image bands...");

    // Staggered geological processing simulation for immersive user experience
    const steps = [
      { p: 15, text: "Analyzing pixel contrast matrix for subsidence geometries..." },
      { p: 35, text: "Calculating soil thermal thermal anomalies & edge displacements..." },
      { p: 55, text: "Cross-referencing global karst index catalogs..." },
      { p: 75, text: "Formulating subsurface cavity risk vectors..." },
      { p: 90, text: "Assembling final geo-spatial report files..." }
    ];

    let stepIdx = 0;
    const interval = setInterval(() => {
      if (stepIdx < steps.length) {
        setAnalysisProgress(steps[stepIdx].p);
        setProgressText(steps[stepIdx].text);
        stepIdx++;
      } else {
        clearInterval(interval);
        submitToBackend();
      }
    }, 850);
  };

  const submitToBackend = async () => {
    try {
      const payload: any = {
        base64Image: uploadedImage,
        fileName: uploadedFileName,
        fileType: selectedFileType
      };

      if (useManualCoordinates) {
        payload.locationOverride = {
          lat: parseFloat(manualLat) || 28.538336,
          lng: parseFloat(manualLng) || -81.379234,
          locationName: manualRegionName || "User Marked Location"
        };
      }

      const res = await fetch('/api/analyze', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      });

      if (!res.ok) {
        const errData = await res.json();
        throw new Error(errData?.error || "Imagery scan failed on backend server.");
      }

      const newScan: ScanRecord = await res.json();
      
      // Update history and load active scan
      setHistory(prev => [newScan, ...prev]);
      setActiveScan(newScan);
      
      // Reset upload preview and progress
      setUploadedImage('');
      setUploadedFileName('');
      setIsAnalyzing(false);
      setAnalysisProgress(0);
      setProgressText('');
    } catch (err: any) {
      console.error(err);
      setErrorMessage(err?.message || "Visual analysis pipeline failed. Please check backend logs.");
      setIsAnalyzing(false);
      setAnalysisProgress(0);
    }
  };

  // Clear a historical record
  const deleteRecord = async (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    if (!confirm("Are you sure you want to permanently delete this geological scan record?")) return;

    try {
      const res = await fetch(`/api/history/${id}`, { method: 'DELETE' });
      if (res.ok) {
        setHistory(prev => {
          const updated = prev.filter(item => item.id !== id);
          if (activeScan?.id === id) {
            setActiveScan(updated.length > 0 ? updated[0] : null);
          }
          return updated;
        });
      }
    } catch (err) {
      console.error("Failed to delete record:", err);
    }
  };

  // Filter & Search Log Logic
  const filteredHistory = history.filter((item) => {
    const matchesSearch = 
      item.id.toLowerCase().includes(searchTerm.toLowerCase()) ||
      item.fileName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      item.location.locationName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      item.soilType.toLowerCase().includes(searchTerm.toLowerCase());

    const matchesType = filterType === 'all' || item.fileType === filterType;
    
    const matchesRisk = 
      filterRisk === 'all' || 
      (filterRisk === 'high' && item.isHighRiskAlert) || 
      (filterRisk === 'stable' && !item.isHighRiskAlert);

    return matchesSearch && matchesType && matchesRisk;
  });

  // Calculate statistics for charts
  const statsTotalScans = history.length;
  const statsHighRiskCount = history.filter(item => item.isHighRiskAlert).length;
  const statsAvgConfidence = history.length > 0
    ? (history.reduce((acc, item) => {
        const scanAvg = item.detections.length > 0 
          ? (item.detections.reduce((sum, det) => sum + det.confidence, 0) / item.detections.length)
          : 0;
        return acc + scanAvg;
      }, 0) / history.length).toFixed(1)
    : "0";

  // Chart data: Size distribution (bounding size vs confidence)
  const chartPoints = history.flatMap(item => 
    item.detections.map(d => ({
      diameter: d.estimatedDiameterMeters,
      confidence: d.confidence,
      riskScore: d.riskScore,
      riskLevel: d.riskLevel,
      location: item.location.locationName
    }))
  ).slice(0, 15); // Top 15 detections for readable scatter chart

  return (
    <div className="min-h-screen bg-[#0A0A0B] text-slate-100 flex flex-col font-sans selection:bg-blue-600 selection:text-white grid-bg relative" id="sinkhole-dashboard-root">
      
      {/* GLOBAL LINEAR GLOW PATTERN */}
      <div className="absolute top-0 left-0 w-full h-[400px] bg-gradient-to-b from-blue-950/10 via-transparent to-transparent pointer-events-none border-b border-white/5" />

      {/* HEADER SECTION */}
      <header className="border-b border-white/10 bg-[#0C0C0E]/90 backdrop-blur-md sticky top-0 z-50 px-6 py-4 flex flex-col lg:flex-row items-center justify-between gap-4" id="app-dashboard-header">
        <div className="flex items-center gap-3 w-full lg:w-auto">
          <div className="p-2.5 bg-blue-600 rounded-xl shadow-[0_0_20px_rgba(37,99,235,0.25)] flex items-center justify-center">
            <Shield className="w-6 h-6 text-white" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="text-[10px] font-mono font-bold tracking-widest text-blue-400 uppercase">Geological Intel Suite</span>
              <span className="px-1.5 py-0.5 text-[8px] font-mono font-black tracking-tighter bg-blue-500/10 text-blue-400 border border-blue-400/20 rounded">V2.4</span>
            </div>
            <h1 className="text-xl font-extrabold tracking-tight text-white flex items-center gap-1.5">
              SINKHOLE AI <span className="font-light text-slate-400">Detector</span>
            </h1>
          </div>
        </div>

        {/* Navigation block matching Design HTML style */}
        <nav className="flex items-center gap-6 text-sm text-slate-400 font-medium">
          <a href="#sinkhole-dashboard-root" className="text-white border-b-2 border-blue-500 pb-1 transition-all">Dashboard</a>
          <a href="#geotechnical-report-section" className="hover:text-white transition-all">Risk Reports</a>
          <a href="#historical-registry-section" className="hover:text-white transition-all">Registry</a>
        </nav>

        {/* Real-time Status Board / Geometric Balance Right Side */}
        <div className="flex flex-wrap items-center gap-4 text-xs font-mono w-full lg:w-auto justify-end">
          {/* Active Sector Dynamic Tag */}
          <div className="flex items-center gap-2 px-3 py-1.5 bg-white/5 border border-white/10 rounded-lg">
            <Compass className="w-3.5 h-3.5 text-blue-400" />
            <span className="text-slate-300 font-semibold">
              {activeScan ? activeScan.location.locationName.split(',')[0] : 'Florida'} Sector
            </span>
          </div>

          <div className="flex items-center gap-2 px-3 py-1.5 bg-white/5 border border-white/10 rounded-lg">
            <Activity className="w-3.5 h-3.5 text-blue-400" />
            <div className="flex items-center gap-1.5">
              <span className="h-1.5 w-1.5 rounded-full bg-blue-500 inline-block animate-ping"></span>
              <span className="text-slate-200 font-bold uppercase">SYSTEM ACTIVE</span>
            </div>
          </div>

          {/* User profile bubble placeholder */}
          <div className="w-8 h-8 rounded-full bg-gradient-to-tr from-blue-600 to-indigo-600 flex items-center justify-center text-xs font-bold text-white border border-white/10 cursor-pointer shadow-md hover:scale-105 transition-all">
            AI
          </div>
        </div>
      </header>

      {/* STATS OVERVIEW CARDS */}
      <section className="px-6 pt-6 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4" id="stats-dashboard-grid">
        <div className="glass-panel glass-panel-hover p-5 rounded-2xl relative overflow-hidden group">
          <div className="absolute top-0 right-0 p-6 opacity-5 text-blue-400 group-hover:scale-110 transition duration-300">
            <Database className="w-16 h-16" />
          </div>
          <span className="text-[10px] font-mono tracking-widest text-slate-400 uppercase">Geological Database</span>
          <div className="text-3xl font-black text-white mt-1">{statsTotalScans}</div>
          <div className="text-xs text-slate-400 mt-2 flex items-center gap-1.5">
            <CheckCircle className="w-3.5 h-3.5 text-blue-400" />
            <span>Multi-spectral imagery logs synced</span>
          </div>
        </div>

        <div className="glass-panel glass-panel-hover p-5 rounded-2xl relative overflow-hidden group">
          <div className="absolute top-0 right-0 p-6 opacity-5 text-red-500 group-hover:scale-110 transition duration-300">
            <AlertTriangle className="w-16 h-16" />
          </div>
          <span className="text-[10px] font-mono tracking-widest text-slate-400 uppercase">Active Hazards</span>
          <div className="text-3xl font-black text-red-400 mt-1">{statsHighRiskCount}</div>
          <div className="text-xs text-slate-400 mt-2 flex items-center gap-1.5">
            <span className={`h-1.5 w-1.5 rounded-full ${statsHighRiskCount > 0 ? 'bg-red-500 animate-pulse' : 'bg-slate-500'} inline-block`}></span>
            <span>Unstable doline areas flagged</span>
          </div>
        </div>

        <div className="glass-panel glass-panel-hover p-5 rounded-2xl relative overflow-hidden group">
          <div className="absolute top-0 right-0 p-6 opacity-5 text-blue-400 group-hover:scale-110 transition duration-300">
            <Cpu className="w-16 h-16" />
          </div>
          <span className="text-[10px] font-mono tracking-widest text-slate-400 uppercase">Average AI Confidence</span>
          <div className="text-3xl font-black text-blue-400 mt-1">{statsAvgConfidence}%</div>
          <div className="text-xs text-slate-400 mt-2 flex items-center gap-1.5">
            <TrendingUp className="w-3.5 h-3.5 text-blue-400" />
            <span>Target matching probability rating</span>
          </div>
        </div>

        <div className="glass-panel p-5 rounded-2xl relative overflow-hidden bg-gradient-to-br from-zinc-900/80 to-blue-950/20 border-blue-500/10">
          <span className="text-[10px] font-mono tracking-widest text-blue-400 uppercase">Operational Mode</span>
          <div className="text-lg font-bold text-white mt-1">Hybrid Multi-Spectral</div>
          <p className="text-[11px] text-slate-400 mt-1 leading-relaxed">
            Uses Gemini 3.5 Vision or high-fidelity simulation model stubs. Toggle Secrets for production keys.
          </p>
        </div>
      </section>

      {/* MAIN BENTO GRID DASHBOARD */}
      <main className="p-6 grid grid-cols-1 lg:grid-cols-12 gap-6 items-stretch flex-grow" id="bento-dashboard-layout">
        
        {/* LEFT COLUMN: CONTROL & FILE UPLOAD HUB (lg:span-4) */}
        <section className="lg:col-span-4 flex flex-col gap-5 glass-panel p-5 rounded-2xl relative" id="control-hub-section">
          <div className="flex items-center gap-2 pb-3 border-b border-white/10">
            <Layers className="w-5 h-5 text-blue-400" />
            <h2 className="font-extrabold text-base text-white tracking-tight uppercase">Scan Administration</h2>
          </div>

          {/* Quick Demo Scenarios Loader */}
          <div>
            <label className="block text-[10px] font-mono text-slate-400 mb-2 uppercase tracking-wider">Load Quick Scenarios</label>
            <div className="grid grid-cols-3 gap-2">
              <button 
                onClick={() => loadDemo('florida')}
                className="px-2 py-2.5 bg-zinc-900/60 border border-white/10 hover:border-blue-500/40 hover:bg-blue-950/10 rounded-xl text-[11px] text-slate-300 transition flex flex-col items-center gap-1 text-center"
              >
                <span className="font-bold text-blue-400">Florida</span>
                <span className="text-[9px] text-slate-500">Satellite view</span>
              </button>
              <button 
                onClick={() => loadDemo('dead_sea')}
                className="px-2 py-2.5 bg-zinc-900/60 border border-white/10 hover:border-blue-500/40 hover:bg-blue-950/10 rounded-xl text-[11px] text-slate-300 transition flex flex-col items-center gap-1 text-center"
              >
                <span className="font-bold text-sky-400">Dead Sea</span>
                <span className="text-[9px] text-slate-500">UAV Drone</span>
              </button>
              <button 
                onClick={() => loadDemo('tennessee')}
                className="px-2 py-2.5 bg-zinc-900/60 border border-white/10 hover:border-blue-500/40 hover:bg-blue-950/10 rounded-xl text-[11px] text-slate-300 transition flex flex-col items-center gap-1 text-center"
              >
                <span className="font-bold text-amber-400">Tennessee</span>
                <span className="text-[9px] text-slate-500">Ground Void</span>
              </button>
            </div>
          </div>

          {/* Image Upload Zone */}
          <div className="flex-grow flex flex-col">
            <label className="block text-[10px] font-mono text-slate-400 mb-2 uppercase tracking-wider">Upload Field Imagery</label>
            <div 
              onDragOver={handleDragOver}
              onDrop={handleDrop}
              className={`flex-grow border-2 border-dashed rounded-2xl flex flex-col items-center justify-center p-6 text-center transition min-h-[170px] ${
                uploadedImage 
                  ? 'border-blue-500/40 bg-blue-500/5' 
                  : 'border-white/10 bg-zinc-950/40 hover:border-white/20 hover:bg-white/5'
              }`}
            >
              {uploadedImage ? (
                <div className="flex flex-col items-center gap-2">
                  <div className="p-3 bg-blue-500/10 rounded-full border border-blue-500/20">
                    <CheckCircle className="w-8 h-8 text-blue-400" />
                  </div>
                  <p className="text-sm font-semibold text-slate-200 line-clamp-1">{uploadedFileName}</p>
                  <p className="text-[10px] font-mono text-slate-500">Image successfully buffered</p>
                  <button 
                    onClick={() => { setUploadedImage(''); setUploadedFileName(''); }}
                    className="mt-2 text-xs font-mono text-red-400 hover:underline hover:text-red-300"
                  >
                    Clear File
                  </button>
                </div>
              ) : (
                <div className="flex flex-col items-center">
                  <div className="p-4 bg-zinc-900 rounded-full border border-white/10 mb-3 group-hover:scale-105 transition">
                    <Upload className="w-7 h-7 text-slate-400" />
                  </div>
                  <p className="text-sm font-semibold text-slate-300">Drag & Drop raw imagery</p>
                  <p className="text-xs text-slate-500 mt-1">Satellite Ortho, Drone JPEG, Ground PNG</p>
                  <label className="mt-4 px-3 py-1.5 bg-zinc-900 border border-white/10 hover:bg-zinc-850 rounded-lg text-xs font-semibold text-slate-300 cursor-pointer transition">
                    Select File
                    <input 
                      type="file" 
                      accept="image/*" 
                      onChange={handleImageUpload} 
                      className="hidden" 
                    />
                  </label>
                </div>
              )}
            </div>
          </div>

          {/* Core Configuration Options */}
          <div className="space-y-4">
            {/* Image Source Type */}
            <div>
              <label className="block text-[10px] font-mono text-slate-400 mb-1.5 uppercase tracking-wider">Imagery Source Class</label>
              <div className="grid grid-cols-3 gap-1 bg-zinc-950 p-1 rounded-xl border border-white/5">
                <button 
                  onClick={() => setSelectedFileType('satellite')}
                  className={`py-1.5 rounded-lg text-xs font-bold transition ${selectedFileType === 'satellite' ? 'bg-blue-600 text-white shadow-sm' : 'text-slate-400 hover:text-slate-200'}`}
                >
                  Satellite
                </button>
                <button 
                  onClick={() => setSelectedFileType('drone')}
                  className={`py-1.5 rounded-lg text-xs font-bold transition ${selectedFileType === 'drone' ? 'bg-blue-600 text-white shadow-sm' : 'text-slate-400 hover:text-slate-200'}`}
                >
                  Drone/UAV
                </button>
                <button 
                  onClick={() => setSelectedFileType('ground')}
                  className={`py-1.5 rounded-lg text-xs font-bold transition ${selectedFileType === 'ground' ? 'bg-blue-600 text-white shadow-sm' : 'text-slate-400 hover:text-slate-200'}`}
                >
                  Ground Photo
                </button>
              </div>
            </div>

            {/* Geological Coordinates Inserter */}
            <div className="bg-zinc-950/60 p-3.5 rounded-xl border border-white/5 space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-[10px] font-mono text-slate-400 uppercase tracking-wider flex items-center gap-1.5">
                  <Compass className="w-3.5 h-3.5 text-blue-400" /> Geospatial Pin
                </span>
                <label className="flex items-center gap-1 cursor-pointer">
                  <input 
                    type="checkbox" 
                    checked={useManualCoordinates}
                    onChange={(e) => setUseManualCoordinates(e.target.checked)}
                    className="rounded border-white/10 text-blue-500 focus:ring-blue-500 h-3.5 w-3.5 bg-zinc-900"
                  />
                  <span className="text-[10px] font-mono text-slate-400">Manual Pin</span>
                </label>
              </div>

              {useManualCoordinates ? (
                <div className="space-y-2">
                  <div className="grid grid-cols-2 gap-2">
                    <div>
                      <span className="text-[9px] font-mono text-slate-500 uppercase">Latitude</span>
                      <input 
                        type="text" 
                        value={manualLat}
                        onChange={(e) => setManualLat(e.target.value)}
                        className="w-full text-xs bg-zinc-900 border border-white/10 rounded px-2 py-1 text-slate-300 font-mono"
                      />
                    </div>
                    <div>
                      <span className="text-[9px] font-mono text-slate-500 uppercase">Longitude</span>
                      <input 
                        type="text" 
                        value={manualLng}
                        onChange={(e) => setManualLng(e.target.value)}
                        className="w-full text-xs bg-zinc-900 border border-white/10 rounded px-2 py-1 text-slate-300 font-mono"
                      />
                    </div>
                  </div>
                  <div>
                    <span className="text-[9px] font-mono text-slate-500 uppercase">Region Name</span>
                    <input 
                      type="text" 
                      value={manualRegionName}
                      onChange={(e) => setManualRegionName(e.target.value)}
                      className="w-full text-xs bg-zinc-900 border border-white/10 rounded px-2 py-1 text-slate-300"
                      placeholder="e.g. Winter Park, Florida"
                    />
                  </div>
                </div>
              ) : (
                <p className="text-[11px] text-slate-400 leading-normal">
                  Location coordinates and region names are automatically predicted based on multi-spectral terrain characteristics.
                </p>
              )}
            </div>
          </div>

          {/* Submit Scan Button */}
          <div className="pt-2">
            <button
              onClick={executeScan}
              disabled={isAnalyzing || !uploadedImage}
              className={`w-full py-3 px-4 rounded-xl font-bold tracking-wide transition flex items-center justify-center gap-2 ${
                isAnalyzing || !uploadedImage
                  ? 'bg-zinc-900/60 text-slate-500 cursor-not-allowed border border-white/5'
                  : 'bg-blue-600 text-white font-extrabold hover:bg-blue-500 active:bg-blue-700 hover:shadow-[0_0_20px_rgba(37,99,235,0.3)] transition-all duration-300'
              }`}
            >
              {isAnalyzing ? (
                <>
                  <Activity className="w-5 h-5 animate-spin" />
                  <span>Processing Multispectral Data...</span>
                </>
              ) : (
                <>
                  <Shield className="w-5 h-5 text-white" />
                  <span>Run Geological AI Scan</span>
                </>
              )}
            </button>

            {/* Error Message */}
            {errorMessage && (
              <div className="mt-3 p-3 bg-red-950/20 border border-red-500/30 text-red-400 text-xs rounded-xl flex items-start gap-2">
                <AlertTriangle className="w-4 h-4 mt-0.5 shrink-0" />
                <p>{errorMessage}</p>
              </div>
            )}
          </div>

          {/* Scanning Progress Screen Overlay */}
          {isAnalyzing && (
            <div className="absolute inset-0 bg-[#0A0A0B]/98 rounded-2xl flex flex-col items-center justify-center p-6 z-20">
              <div className="w-16 h-16 relative flex items-center justify-center mb-4">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-blue-500/20 opacity-75"></span>
                <Cpu className="w-10 h-10 text-blue-400 animate-pulse" />
              </div>
              <h3 className="text-white font-bold text-lg mb-1">Geological Core Online</h3>
              <p className="text-xs text-slate-400 mb-6 font-mono tracking-widest uppercase">Analyzing Multi-Spectral Layer</p>
              
              {/* Progress bar */}
              <div className="w-full bg-zinc-900 h-2 rounded-full border border-white/10 overflow-hidden max-w-[280px]">
                <div 
                  className="bg-blue-600 h-full rounded-full transition-all duration-300"
                  style={{ width: `${analysisProgress}%` }}
                />
              </div>
              <p className="text-[10px] font-mono text-blue-400 mt-3 text-center px-4 max-w-[300px] h-8 leading-relaxed">
                {progressText}
              </p>
            </div>
          )}
        </section>

        {/* MIDDLE COLUMN: ACTIVE IMAGE VIEWER & BOUNDING BOX OVERLAYS (lg:span-5) */}
        <section className="lg:col-span-5 glass-panel p-5 rounded-2xl flex flex-col justify-between animate-fade-in" id="imagery-viewer-section">
          
          <div className="flex items-center justify-between pb-3 border-b border-white/10 mb-4">
            <div className="flex items-center gap-2">
              <Eye className="w-5 h-5 text-blue-400" />
              <h2 className="font-extrabold text-base text-white tracking-tight uppercase">Advanced Visualizer</h2>
            </div>
            {activeScan && (
              <span className={`px-2.5 py-1 rounded-full text-[10px] font-bold uppercase tracking-wider font-mono ${
                activeScan.isHighRiskAlert 
                  ? 'bg-red-500/10 text-red-400 border border-red-500/20' 
                  : 'bg-blue-500/10 text-blue-400 border border-blue-500/20'
              }`}>
                {activeScan.isHighRiskAlert ? 'CRITICAL SUBSIDENCE ZONE' : 'STABLE FORMATION'}
              </span>
            )}
          </div>

          {/* Active Image Box */}
          <div className="relative bg-zinc-950 border border-white/5 rounded-xl overflow-hidden aspect-square flex items-center justify-center flex-grow" id="viewport-image-box">
            {activeScan ? (
              <div className="relative w-full h-full flex items-center justify-center">
                {/* Fallback pattern if imageUrl is empty (e.g. historical default loads) */}
                {activeScan.imageUrl ? (
                  <img 
                    src={activeScan.imageUrl} 
                    alt={activeScan.fileName} 
                    className="w-full h-full object-contain"
                  />
                ) : (
                  <div className="w-full h-full bg-[#0d0d11] flex flex-col items-center justify-center p-6 text-center select-none relative">
                    <Database className="w-16 h-16 text-slate-800 mb-2 animate-pulse" />
                    <span className="text-xs text-slate-500 font-mono">{activeScan.fileName}</span>
                    <span className="text-[10px] text-blue-500/70 font-mono mt-1">Preset Vector Ortho Cached</span>
                    <div className="absolute inset-0 bg-blue-950/5 border border-white/5 rounded-xl pointer-events-none" />
                  </div>
                )}

                {/* Spectral Scan Line Animation */}
                {isAnalyzing && (
                  <div className="absolute top-0 left-0 w-full h-[3px] bg-blue-400 shadow-[0_0_15px_#2563eb] animate-[bounce_3s_infinite]" />
                )}

                {/* Bounding Box Overlays */}
                {!isAnalyzing && activeScan.detections.map((det, idx) => {
                  const [ymin, xmin, ymax, xmax] = det.box;
                  const isHovered = hoveredBoxIdx === idx;
                  
                  return (
                    <div
                      key={idx}
                      className={`absolute cursor-pointer transition-all duration-250 ${
                        det.riskLevel === 'high' 
                          ? 'border-2 border-red-500 bg-red-500/10 hover:bg-red-500/20 shadow-[0_0_15px_rgba(239,68,68,0.4)]' 
                          : 'border-2 border-amber-500 bg-amber-500/10 hover:bg-amber-500/20 shadow-[0_0_15px_rgba(245,158,11,0.4)]'
                      } ${isHovered ? 'ring-2 ring-white scale-[1.01] z-10' : 'z-5'}`}
                      style={{
                        top: `${ymin}%`,
                        left: `${xmin}%`,
                        width: `${xmax - xmin}%`,
                        height: `${ymax - ymin}%`,
                      }}
                      onMouseEnter={() => setHoveredBoxIdx(idx)}
                      onMouseLeave={() => setHoveredBoxIdx(null)}
                    >
                      {/* Bounding box badge label */}
                      <span className={`absolute -top-5 left-0 px-1.5 py-0.5 text-[9px] font-mono font-bold rounded shadow-lg text-white border ${
                        det.riskLevel === 'high' 
                          ? 'bg-red-600 border-red-500' 
                          : 'bg-amber-600 border-amber-500'
                      }`}>
                        SH-{idx + 1}: {det.confidence}%
                      </span>
                    </div>
                  );
                })}
              </div>
            ) : (
              <div className="p-8 text-center flex flex-col items-center">
                <Database className="w-12 h-12 text-slate-800 mb-3" />
                <p className="text-sm font-semibold text-slate-400">No active geological scan loaded</p>
                <p className="text-xs text-slate-600 mt-1 max-w-[280px]">
                  Use the Scan Administration panel on the left to upload or select a scenario preset.
                </p>
              </div>
            )}
          </div>

          {/* Active Image Metadata Banner */}
          {activeScan && (
            <div className="mt-4 p-3 bg-zinc-950 border border-white/5 rounded-xl flex items-center justify-between text-xs font-mono">
              <div>
                <span className="text-slate-500">Target File: </span>
                <span className="text-slate-300 font-bold max-w-[150px] truncate inline-block align-bottom">{activeScan.fileName}</span>
              </div>
              <div className="flex items-center gap-3">
                <div>
                  <span className="text-slate-500">Method: </span>
                  <span className="text-blue-400 capitalize font-bold">{activeScan.fileType}</span>
                </div>
                <div>
                  <span className="text-slate-500">Voids: </span>
                  <span className="text-red-400 font-bold">{activeScan.detections.length}</span>
                </div>
              </div>
            </div>
          )}
        </section>

        {/* RIGHT COLUMN: DETAILED REPORT & GEO-MAP VIEW (lg:span-3) */}
        <section className="lg:col-span-3 flex flex-col gap-5 glass-panel p-5 rounded-2xl relative" id="geotechnical-report-section">
          
          <div className="flex items-center gap-2 pb-3 border-b border-white/10">
            <FileText className="w-5 h-5 text-blue-400" />
            <h2 className="font-extrabold text-base text-white tracking-tight uppercase">Geotechnical Intel</h2>
          </div>

          {activeScan ? (
            <div className="flex-grow flex flex-col gap-4 overflow-y-auto" style={{ maxHeight: '550px' }}>
              
              {/* Alert Level Banner */}
              <div className={`p-4 rounded-xl border flex items-start gap-3 ${
                activeScan.isHighRiskAlert 
                  ? 'bg-red-500/5 border-red-500/20 text-red-200' 
                  : 'bg-blue-500/5 border-blue-500/10 text-blue-200'
              }`}>
                <AlertTriangle className={`w-5 h-5 mt-0.5 shrink-0 ${activeScan.isHighRiskAlert ? 'text-red-400 animate-bounce' : 'text-blue-400'}`} />
                <div>
                  <h4 className="text-xs font-bold font-mono tracking-wider uppercase">
                    {activeScan.isHighRiskAlert ? 'CRITICAL SUBSIDENCE ALERT' : 'SECURE DEPOSIT CONFIG'}
                  </h4>
                  <p className="text-[11px] text-slate-400 mt-1 leading-normal">
                    {activeScan.isHighRiskAlert 
                      ? 'Subsidence detected on site. Severe threat of cover-collapse. Evacuate proximity.' 
                      : 'Underlying limestone strata shows low degradation. Recommended monitoring period: 360 days.'}
                  </p>
                </div>
              </div>

              {/* Soil / Geology Profile Card */}
              <div className="bg-zinc-950/60 border border-white/5 rounded-xl p-3.5 space-y-1">
                <span className="text-[10px] font-mono tracking-wider text-slate-500 uppercase flex items-center gap-1.5">
                  <Layers className="w-3.5 h-3.5 text-blue-400" /> Bedrock Composition
                </span>
                <p className="text-sm font-black text-slate-200">{activeScan.soilType}</p>
                <p className="text-[11px] text-slate-400 leading-relaxed pt-1.5 border-t border-white/5 mt-1.5">
                  <strong>Assessment:</strong> {activeScan.geologicalRiskAssessment}
                </p>
              </div>

              {/* Delineated Voids List */}
              <div className="space-y-2">
                <span className="text-[10px] font-mono tracking-wider text-slate-500 uppercase">Delineated Subsurface Voids</span>
                
                {activeScan.detections.length === 0 ? (
                  <p className="text-xs text-slate-500 italic p-3 text-center border border-dashed border-white/5 rounded-xl">
                    No voids delineated in this viewport scan.
                  </p>
                ) : (
                  activeScan.detections.map((det, idx) => {
                    const isHovered = hoveredBoxIdx === idx;
                    
                    return (
                      <div
                        key={idx}
                        className={`p-3 rounded-xl border transition duration-200 cursor-pointer ${
                          isHovered 
                            ? 'bg-blue-950/20 border-blue-500/50 shadow-md' 
                            : 'bg-zinc-950/60 border-white/5 hover:bg-zinc-900/40'
                        }`}
                        onMouseEnter={() => setHoveredBoxIdx(idx)}
                        onMouseLeave={() => setHoveredBoxIdx(null)}
                      >
                        <div className="flex items-center justify-between gap-1">
                          <span className="font-mono text-xs font-bold text-blue-400">Void SH-{idx + 1}</span>
                          <span className={`px-2 py-0.5 rounded text-[9px] font-bold uppercase font-mono ${
                            det.riskLevel === 'high' ? 'bg-red-950/30 text-red-400 border border-red-500/20' : 'bg-amber-950/30 text-amber-400 border border-amber-500/20'
                          }`}>
                            Risk Score: {det.riskScore}
                          </span>
                        </div>

                        <div className="grid grid-cols-2 gap-2 mt-2 pt-2 border-t border-white/5 text-[11px] font-mono">
                          <div>
                            <span className="text-slate-500">Diameter: </span>
                            <span className="text-slate-200 font-bold">{det.estimatedDiameterMeters}m</span>
                          </div>
                          <div>
                            <span className="text-slate-500">Confidence: </span>
                            <span className="text-slate-200 font-bold">{det.confidence}%</span>
                          </div>
                        </div>

                        <p className="text-[11px] text-slate-400 leading-normal mt-2 text-justify">
                          {det.description}
                        </p>

                        <div className="flex items-center gap-1 mt-2 pt-1 text-[9px] font-mono text-slate-500">
                          <MapPin className="w-3 h-3 text-blue-400" />
                          <span className="truncate">
                            {typeof det.latitude === 'number' ? det.latitude.toFixed(5) : activeScan.location.lat.toFixed(5)},{' '}
                            {typeof det.longitude === 'number' ? det.longitude.toFixed(5) : activeScan.location.lng.toFixed(5)}
                          </span>
                        </div>
                      </div>
                    );
                  })
                )}
              </div>

              {/* Embedded Geo-Spatial Leaflet Map */}
              <div className="space-y-2 mt-2">
                <span className="text-[10px] font-mono tracking-wider text-slate-500 uppercase flex items-center gap-1">
                  <MapIcon className="w-3.5 h-3.5 text-blue-400" /> Terrain Grid Locator
                </span>
                <div 
                  id={mapContainerId}
                  className="w-full h-[180px] rounded-xl border border-white/5 overflow-hidden relative shadow-inner"
                />
                <p className="text-[9px] font-mono text-slate-500 text-center leading-normal">
                  Showing active coordinates: {activeScan.location.lat.toFixed(5)}, {activeScan.location.lng.toFixed(5)}
                </p>
              </div>

            </div>
          ) : (
            <div className="flex-grow flex flex-col items-center justify-center text-center p-8">
              <Info className="w-8 h-8 text-slate-800 mb-2" />
              <p className="text-xs text-slate-400">Please load or execute an active scan to inspect detailed geotechnical assessment cards.</p>
            </div>
          )}
        </section>

      </main>

      {/* BOTTOM SECTION: ANALYTICS CHARTS & HISTORICAL SCAN REGISTRY */}
      <section className="p-6 border-t border-white/10 bg-[#070708]/80" id="historical-registry-section">
        
        {/* SECTION HEADERS */}
        <div className="flex items-center gap-2 pb-4 mb-6 border-b border-white/10">
          <History className="w-5.5 h-5.5 text-blue-400" />
          <h2 className="text-xl font-bold text-white tracking-tight">Geological Analytics & Historical Registry</h2>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
          
          {/* ANALYTICS CHARTS: CUSTOM HAND-CRAFTED RESPONSIVE SVGS (lg:span-4) */}
          <div className="lg:col-span-4 glass-panel p-5 rounded-2xl space-y-4" id="analytics-charts-box">
            <span className="text-xs font-mono tracking-widest text-blue-400 uppercase flex items-center gap-1.5">
              <TrendingUp className="w-4 h-4 text-blue-400" /> Visual Terrain Statistics
            </span>

            {history.length === 0 ? (
              <div className="py-12 text-center text-xs text-slate-500 italic">
                Add scans to populate statistical graphs
              </div>
            ) : (
              <div className="space-y-6">
                
                {/* Chart 1: Circular Doline Sizes vs Confidence Scatter Plot */}
                <div className="bg-zinc-950 p-4 rounded-xl border border-white/5">
                  <h4 className="text-xs font-semibold text-slate-300 mb-3 font-mono uppercase tracking-wider">Estimated Diameter vs. Confidence Index</h4>
                  
                  <div className="relative w-full h-[150px]">
                    <svg className="w-full h-full" viewBox="0 0 300 150">
                      {/* Grid Lines */}
                      <line x1="20" y1="130" x2="290" y2="130" stroke="#27272a" strokeWidth="1.5" />
                      <line x1="20" y1="10" x2="20" y2="130" stroke="#27272a" strokeWidth="1.5" />
                      <line x1="20" y1="70" x2="290" y2="70" stroke="#27272a" strokeWidth="1" strokeDasharray="4,4" />
                      
                      {/* X and Y labels */}
                      <text x="280" y="142" fill="#64748b" fontSize="7" textAnchor="end">Diameter (m)</text>
                      <text x="5" y="15" fill="#64748b" fontSize="7" transform="rotate(-90 5 15)">Confidence (%)</text>
                      
                      {/* Plot Points */}
                      {chartPoints.map((pt, i) => {
                        // Max diameter 80m for scale, max confidence 100
                        const cx = 20 + (Math.min(pt.diameter, 80) / 80) * 250;
                        const cy = 130 - (pt.confidence / 100) * 110;
                        const isHigh = pt.riskLevel === 'high';
                        
                        return (
                          <g key={i}>
                            <circle 
                              cx={cx} 
                              cy={cy} 
                              r="5" 
                              className={`animate-pulse cursor-pointer hover:stroke-white hover:stroke-2 transition-all ${isHigh ? 'fill-red-500 shadow' : 'fill-amber-500'}`} 
                            />
                            <title>{pt.location}: {pt.diameter}m ({pt.confidence}%)</title>
                          </g>
                        );
                      })}
                    </svg>
                  </div>
                  <div className="flex justify-between items-center text-[9px] font-mono text-slate-500 mt-2">
                    <span className="flex items-center gap-1"><span className="h-2.5 w-2.5 rounded-full bg-red-500 inline-block"></span> High Risk Collapse</span>
                    <span className="flex items-center gap-1"><span className="h-2.5 w-2.5 rounded-full bg-amber-500 inline-block"></span> Medium Risk Sagging</span>
                  </div>
                </div>

                {/* Chart 2: Soil Strata Risk Factor Index */}
                <div className="bg-zinc-950 p-4 rounded-xl border border-white/5">
                  <h4 className="text-xs font-semibold text-slate-300 mb-3 font-mono uppercase tracking-wider">Subsurface Soil Anomaly Displacements</h4>
                  
                  <div className="space-y-3">
                    {history.slice(0, 4).map((scan, i) => {
                      // Calculate total risk score
                      const totalRisk = scan.detections.reduce((sum, d) => sum + d.riskScore, 0);
                      const displayScore = scan.detections.length > 0 ? Math.floor(totalRisk / scan.detections.length) : 0;
                      
                      return (
                        <div key={i} className="space-y-1.5">
                          <div className="flex justify-between text-[10px] font-mono">
                            <span className="text-slate-300 truncate max-w-[170px]">{scan.fileName}</span>
                            <span className={scan.isHighRiskAlert ? 'text-red-400 font-bold' : 'text-blue-400'}>
                              {displayScore}/100 Index
                            </span>
                          </div>
                          <div className="w-full bg-zinc-900 h-2 rounded-full overflow-hidden border border-white/5">
                            <div 
                              className={`h-full rounded-full ${scan.isHighRiskAlert ? 'bg-red-500' : 'bg-blue-600'}`}
                              style={{ width: `${displayScore}%` }}
                            />
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </div>

              </div>
            )}
          </div>

          {/* HISTORICAL REGISTRY SEARCH & LOG TABLE (lg:span-8) */}
          <div className="lg:col-span-8 glass-panel p-5 rounded-2xl space-y-4" id="scan-history-table">
            
            {/* Filter and Search Bar Row */}
            <div className="flex flex-col md:flex-row items-stretch md:items-center justify-between gap-3 pb-3 border-b border-white/10">
              <span className="text-xs font-mono tracking-widest text-slate-400 uppercase">Geological Register</span>
              
              <div className="flex flex-wrap items-center gap-2">
                {/* Text Search Input */}
                <input 
                  type="text"
                  placeholder="Search file, region, geology..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="px-3 py-1.5 bg-zinc-950 border border-white/10 rounded-xl text-xs text-slate-300 placeholder-slate-600 focus:outline-none focus:border-blue-500 w-full md:w-52"
                />

                {/* Filter Image Type */}
                <select
                  value={filterType}
                  onChange={(e) => setFilterType(e.target.value)}
                  className="px-2.5 py-1.5 bg-zinc-950 border border-white/10 rounded-xl text-xs text-slate-300 focus:outline-none cursor-pointer"
                >
                  <option value="all">All Platforms</option>
                  <option value="satellite">Satellite</option>
                  <option value="drone">Drone UAV</option>
                  <option value="ground">Ground photography</option>
                </select>

                {/* Filter Risk level */}
                <select
                  value={filterRisk}
                  onChange={(e) => setFilterRisk(e.target.value)}
                  className="px-2.5 py-1.5 bg-zinc-950 border border-white/10 rounded-xl text-xs text-slate-300 focus:outline-none cursor-pointer"
                >
                  <option value="all">All Risks</option>
                  <option value="high">Critical Hazards</option>
                  <option value="stable">Stable Formations</option>
                </select>
              </div>
            </div>

            {/* Historical Scan Logs Table */}
            <div className="overflow-x-auto rounded-xl border border-white/5 bg-zinc-950/40">
              <table className="w-full text-left border-collapse text-xs">
                <thead>
                  <tr className="bg-zinc-950 text-slate-400 font-mono border-b border-white/5">
                    <th className="p-3">Scan ID</th>
                    <th className="p-3">Registry Date</th>
                    <th className="p-3">File Name</th>
                    <th className="p-3">Platform Type</th>
                    <th className="p-3">Geographic Region</th>
                    <th className="p-3">Bedrock Strata</th>
                    <th className="p-3">Risk Status</th>
                    <th className="p-3 text-right">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-white/5 text-slate-300">
                  {filteredHistory.length === 0 ? (
                    <tr>
                      <td colSpan={8} className="p-6 text-center text-slate-500 italic">
                        No geological scans match the specified registry filters.
                      </td>
                    </tr>
                  ) : (
                    filteredHistory.map((scan) => {
                      const isActive = activeScan?.id === scan.id;
                      
                      return (
                        <tr 
                          key={scan.id}
                          onClick={() => setActiveScan(scan)}
                          className={`hover:bg-white/5 cursor-pointer transition ${
                            isActive ? 'bg-blue-500/10 text-blue-400 font-bold border-l-2 border-blue-500' : ''
                          }`}
                        >
                          <td className="p-3 font-mono font-bold text-slate-400">{scan.id}</td>
                          <td className="p-3 font-mono text-[11px] text-slate-500">
                            {new Date(scan.timestamp).toLocaleString(undefined, {
                              month: 'short',
                              day: '2-digit',
                              hour: '2-digit',
                              minute: '2-digit'
                            })}
                          </td>
                          <td className="p-3 max-w-[120px] truncate">{scan.fileName}</td>
                          <td className="p-3 capitalize font-mono text-[10px]">{scan.fileType}</td>
                          <td className="p-3 max-w-[140px] truncate">{scan.location.locationName}</td>
                          <td className="p-3 max-w-[120px] truncate">{scan.soilType}</td>
                          <td className="p-3">
                            <span className={`px-2 py-0.5 rounded text-[9px] font-bold uppercase font-mono border ${
                              scan.isHighRiskAlert 
                                ? 'bg-red-500/10 text-red-400 border-red-500/20' 
                                : 'bg-blue-500/10 text-blue-400 border-blue-500/20'
                            }`}>
                              {scan.isHighRiskAlert ? 'HAZARD' : 'SECURE'}
                            </span>
                          </td>
                          <td className="p-3 text-right" onClick={(e) => e.stopPropagation()}>
                            <div className="flex justify-end gap-1.5">
                              <button
                                onClick={() => setActiveScan(scan)}
                                className="p-1 text-slate-400 hover:text-blue-400 hover:bg-zinc-900 rounded transition cursor-pointer"
                                title="Inspect imagery"
                              >
                                <Eye className="w-4 h-4" />
                              </button>
                              <button
                                onClick={(e) => deleteRecord(scan.id, e)}
                                className="p-1 text-slate-400 hover:text-red-400 hover:bg-zinc-900 rounded transition cursor-pointer"
                                title="Delete Scan"
                              >
                                <Trash2 className="w-4 h-4" />
                              </button>
                            </div>
                          </td>
                        </tr>
                      );
                    })
                  )}
                </tbody>
              </table>
            </div>

            {/* Total count indicator */}
            <div className="flex justify-between items-center text-[11px] font-mono text-slate-500">
              <span>Showing {filteredHistory.length} of {history.length} registry entries</span>
              {history.length > 0 && (
                <button
                  onClick={() => {
                    if (confirm("Reset historical registry to initial geological mock default scans?")) {
                      localStorage.clear();
                      // Call backend delete triggers or refresh
                      location.reload();
                    }
                  }}
                  className="flex items-center gap-1 hover:text-slate-300 transition cursor-pointer"
                >
                  <RotateCcw className="w-3.5 h-3.5" /> Reset Registry
                </button>
              )}
            </div>

          </div>

        </div>

      </section>

      {/* FOOTER METADATA */}
      <footer className="mt-auto border-t border-white/10 bg-[#070708] p-6 text-center text-xs font-mono text-slate-500">
        <p className="flex items-center justify-center gap-1.5">
          <Shield className="w-4 h-4 text-blue-500/60" /> 
          <span>SINKHOLE AI Multi-Spectral Detection Suite</span>
          <span>•</span>
          <span>Client: React-Leaflet</span>
          <span>•</span>
          <span>Backend: Express-Node</span>
        </p>
        <p className="mt-1 text-slate-600">
          Subsurface void assessment model stubs. Not a substitute for physical borehole geotechnical inspection reports.
        </p>
      </footer>

    </div>
  );
}
